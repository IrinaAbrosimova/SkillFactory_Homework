import json
import requests
from config import exchanges


class ConvertionException(Exception):
    pass


class Convertor:
    @staticmethod
    def get_price(quote, base, amount):
        try:
            quote_key = exchanges[quote.lower()]
        except KeyError:
            raise ConvertionException(f"Валюта {quote} не найдена!")

        try:
            base_key = exchanges[base.lower()]
        except KeyError:
            raise ConvertionException(f"Валюта {base} не найдена!")

        if quote_key == base_key:
            raise ConvertionException(f'Невозможно перевести одинаковые валюты {base}!')

        try:
            amount = float(amount)
        except ValueError:
            raise ConvertionException(f'Не удалось обработать количество {amount}!')

        r = requests.get(f"https://min-api.cryptocompare.com/data/price?fsym={exchanges[quote]}&tsyms={exchanges[base]}")
        resp = json.loads(r.content)[exchanges[base]]
        price = resp * amount
        new_price = round(price, 3)
        message = f"Цена {amount} {quote} в {base}: {new_price}"
        return message
