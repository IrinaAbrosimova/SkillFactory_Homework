TOKEN = "6185027674:AAE-f2uZj9bRzrN4iEtjChc623fUewiVd1o"
exchanges = {
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUB'
}
