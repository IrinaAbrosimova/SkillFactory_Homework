import telebot
from extensions import ConvertionException, Convertor
from config import TOKEN, exchanges
import traceback


bot = telebot.TeleBot(TOKEN)


@bot.message_handler(commands=['start', 'help'])
def start(message: telebot.types.Message):
    text = "Добрый день. \
\n \
\nЧтобы начать работу введите информацию через пробел в формате: \
\n \
\n \
1. Валюты, из которой необходимо перевести\
\n \
2. Валюту, в которую необходимо перевести\
\n \
3. Количество\
\n \
\nУвидеть список всех доступных валют: /values"
    bot.send_message(message.chat.id, text)


@bot.message_handler(commands=['values'])
def values(message: telebot.types.Message):
    text = 'Доступные валюты:'
    for key in exchanges.keys():
        text = '\n'.join((text, key, ))
    bot.reply_to(message, text)


@bot.message_handler(content_types=['text'])
def converter(message: telebot.types.Message):

    values = message.text.split(' ')

    try:
        if len(values) != 3:
            raise ConvertionException('Неверное количество параметров!')
        answer = Convertor.get_price(*values)
    except ConvertionException as e:
        bot.reply_to(message, f"Ошибка в команде:\n{e}")
    except Exception as e:
        traceback.print_tb(e.__traceback__)
        bot.reply_to(message, f"Неизвестная ошибка:\n{e}")
    else:
        bot.reply_to(message, answer)


bot.polling()
